from app.models import User, Post
from app import app, db

@app.shell_context_processor
def make_shell_context():
    return {'db': db, 'User': User, 'Post': Post}

'''Criar ou acessar o ambiente: virtualenv .env
Criar ambiente no python 3.7: virtualenv -p python3 .env
Ativar: source .env/bin/activate
Desativar: deactivate
Rodar: flask run
Instalar os requerimentos: pip3 install -r requirements.txt

se não for: pip3 install -r agenda/requirements.txt'''